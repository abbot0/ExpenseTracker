<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.Expense" %>
<% Expense expense = (Expense) request.getAttribute("expense"); %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Expense - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>
<div class="container py-4" style="max-width:640px">
    <div class="d-flex align-items-center gap-2 mb-4">
        <a href="${pageContext.request.contextPath}/expense/list" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left"></i>
        </a>
        <h5 class="mb-0">Edit Expense</h5>
    </div>

    <% if (request.getAttribute("error") != null) { %>
    <div class="alert alert-danger"><i class="bi bi-exclamation-circle me-2"></i>${error}</div>
    <% } %>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <form action="${pageContext.request.contextPath}/expense/edit" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<%= expense.getId() %>">
                <div class="mb-3">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="title" value="<%= expense.getTitle() %>" required maxlength="100">
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-sm-6">
                        <label class="form-label">Amount (&#8377;) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">&#8377;</span>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0.01"
                                   value="<%= expense.getAmount() %>" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label class="form-label">Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="expenseDate"
                               value="<%= expense.getExpenseDate() %>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Category <span class="text-danger">*</span></label>
                    <select class="form-select" name="categoryId" required>
                        <option value="">Select category...</option>
                        <% String[] catNames = {"Food & Dining","Transportation","Housing","Entertainment","Healthcare","Shopping","Education","Utilities","Travel","Other"};
                           for (int i = 1; i <= 10; i++) { %>
                        <option value="<%= i %>" <%= expense.getCategoryId() == i ? "selected" : "" %>><%= catNames[i-1] %></option>
                        <% } %>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3"><%= expense.getDescription() != null ? expense.getDescription() : "" %></textarea>
                </div>
                <div class="mb-4">
                    <label class="form-label">Replace Receipt (optional)</label>
                    <input type="file" class="form-control" name="receipt" accept="image/*,.pdf">
                    <% if (expense.getReceiptPath() != null && !expense.getReceiptPath().isEmpty()) { %>
                    <div class="form-text text-success"><i class="bi bi-paperclip me-1"></i>Receipt attached</div>
                    <% } %>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-fill">
                        <i class="bi bi-check-circle me-2"></i>Save Changes
                    </button>
                    <a href="${pageContext.request.contextPath}/expense/list" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

