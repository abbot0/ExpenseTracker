'use strict';

document.addEventListener('DOMContentLoaded', function () {
    // Bootstrap-style client-side validation
    const forms = document.querySelectorAll('form[novalidate]');
    forms.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Password match validation
    const confirmInput = document.getElementById('confirmPassword');
    const passwordInput = document.getElementById('password');
    if (confirmInput && passwordInput) {
        confirmInput.addEventListener('input', function () {
            if (this.value !== passwordInput.value) {
                this.setCustomValidity('Passwords do not match.');
            } else {
                this.setCustomValidity('');
            }
        });
    }

    // Auto-dismiss alerts after 5 seconds
    document.querySelectorAll('.alert:not(.alert-permanent)').forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity .4s';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 400);
        }, 5000);
    });
});
