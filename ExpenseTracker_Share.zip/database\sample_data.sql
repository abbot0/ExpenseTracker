USE expense_tracker;

-- Password is 'password123' hashed with BCrypt
INSERT INTO users (username, email, password_hash, full_name) VALUES
('johndoe', 'john@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'John Doe'),
('janedoe', 'jane@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Jane Doe');

-- Sample expenses for user 1 (last 3 months)
INSERT INTO expenses (user_id, category_id, title, amount, expense_date, description) VALUES
(1, 1, 'Grocery Store', 85.50, DATE_FORMAT(NOW() - INTERVAL 2 DAY, '%Y-%m-%d'), 'Weekly groceries'),
(1, 2, 'Gas Station', 45.00, DATE_FORMAT(NOW() - INTERVAL 3 DAY, '%Y-%m-%d'), 'Fuel for car'),
(1, 4, 'Netflix', 15.99, DATE_FORMAT(NOW() - INTERVAL 5 DAY, '%Y-%m-%d'), 'Monthly subscription'),
(1, 1, 'Restaurant Dinner', 62.00, DATE_FORMAT(NOW() - INTERVAL 7 DAY, '%Y-%m-%d'), 'Dinner with family'),
(1, 8, 'Electric Bill', 120.00, DATE_FORMAT(NOW() - INTERVAL 10 DAY, '%Y-%m-%d'), 'Monthly electricity'),
(1, 6, 'Amazon Order', 89.99, DATE_FORMAT(NOW() - INTERVAL 12 DAY, '%Y-%m-%d'), 'Home supplies'),
(1, 5, 'Pharmacy', 34.50, DATE_FORMAT(NOW() - INTERVAL 15 DAY, '%Y-%m-%d'), 'Medications'),
(1, 2, 'Uber', 18.75, DATE_FORMAT(NOW() - INTERVAL 18 DAY, '%Y-%m-%d'), 'Ride to airport'),
(1, 1, 'Coffee Shop', 12.40, DATE_FORMAT(NOW() - INTERVAL 20 DAY, '%Y-%m-%d'), 'Morning coffee'),
(1, 7, 'Online Course', 49.00, DATE_FORMAT(NOW() - INTERVAL 25 DAY, '%Y-%m-%d'), 'Java programming course'),
(1, 1, 'Grocery Store', 92.30, DATE_FORMAT(NOW() - INTERVAL 30 DAY, '%Y-%m-%d'), 'Monthly groceries'),
(1, 3, 'Rent', 1200.00, DATE_FORMAT(NOW() - INTERVAL 32 DAY, '%Y-%m-%d'), 'Monthly rent'),
(1, 9, 'Hotel', 250.00, DATE_FORMAT(NOW() - INTERVAL 45 DAY, '%Y-%m-%d'), 'Weekend trip'),
(1, 4, 'Cinema', 28.00, DATE_FORMAT(NOW() - INTERVAL 50 DAY, '%Y-%m-%d'), 'Movie night'),
(1, 8, 'Internet Bill', 60.00, DATE_FORMAT(NOW() - INTERVAL 60 DAY, '%Y-%m-%d'), 'Monthly internet');

-- Sample budgets for user 1 (current month)
INSERT INTO budgets (user_id, category_id, month, year, amount) VALUES
(1, 1, MONTH(NOW()), YEAR(NOW()), 400.00),
(1, 2, MONTH(NOW()), YEAR(NOW()), 150.00),
(1, 3, MONTH(NOW()), YEAR(NOW()), 1200.00),
(1, 4, MONTH(NOW()), YEAR(NOW()), 100.00),
(1, 5, MONTH(NOW()), YEAR(NOW()), 100.00),
(1, 6, MONTH(NOW()), YEAR(NOW()), 200.00),
(1, 8, MONTH(NOW()), YEAR(NOW()), 200.00);
