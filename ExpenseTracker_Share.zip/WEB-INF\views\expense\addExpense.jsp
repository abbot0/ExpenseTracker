<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Expense - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>
<div class="container py-4" style="max-width:640px">
    <div class="d-flex align-items-center gap-2 mb-4">
        <a href="${pageContext.request.contextPath}/expense/list" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left"></i>
        </a>
        <h5 class="mb-0">Add New Expense</h5>
    </div>

    <% if (request.getAttribute("error") != null) { %>
    <div class="alert alert-danger"><i class="bi bi-exclamation-circle me-2"></i>${error}</div>
    <% } %>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <form action="${pageContext.request.contextPath}/expense/add" method="post" enctype="multipart/form-data" id="expenseForm">
                <div class="mb-3">
                    <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="e.g. Grocery Store" required maxlength="100">
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-sm-6">
                        <label for="amount" class="form-label">Amount (&#8377;) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">&#8377;</span>
                            <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0.01" placeholder="0.00" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label for="expenseDate" class="form-label">Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="expenseDate" name="expenseDate" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="categoryId" class="form-label">Category <span class="text-danger">*</span></label>
                    <select class="form-select" id="categoryId" name="categoryId" required>
                        <option value="">Select category...</option>
                        <option value="1">ðŸœ Food &amp; Dining</option>
                        <option value="2">ðŸš -  Transportation</option>
                        <option value="3">ðŸ  Housing</option>
                        <option value="4">ðŸŽ® Entertainment</option>
                        <option value="5">â¤ï¸ Healthcare</option>
                        <option value="6">ðŸ›ï¸ Shopping</option>
                        <option value="7">ðŸ“š Education</option>
                        <option value="8">âš¡ Utilities</option>
                        <option value="9">âœˆï¸ Travel</option>
                        <option value="10">ðŸ“Œ Other</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Optional notes..."></textarea>
                </div>
                <div class="mb-4">
                    <label for="receipt" class="form-label">Receipt (optional)</label>
                    <input type="file" class="form-control" id="receipt" name="receipt" accept="image/*,.pdf">
                    <div class="form-text">Max 5MB. JPG, PNG, or PDF.</div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-fill">
                        <i class="bi bi-check-circle me-2"></i>Save Expense
                    </button>
                    <a href="${pageContext.request.contextPath}/expense/list" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/validation.js"></script>
<script>
    document.getElementById('expenseDate').valueAsDate = new Date();
</script>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

