package controller;

import dao.ExpenseDAO;
import model.Expense;
import util.SessionUtil;
import util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/expense/*")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024) // 5MB
public class ExpenseServlet extends HttpServlet {

    private final ExpenseDAO expenseDAO = new ExpenseDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String path = req.getPathInfo();
        if (path == null) path = "/list";
        int userId = SessionUtil.getUserId(req);

        try {
            switch (path) {
                case "/add":
                    req.getRequestDispatcher("/WEB-INF/views/expense/addExpense.jsp").forward(req, res);
                    break;
                case "/list":
                    List<Expense> expenses = expenseDAO.findByUser(userId);
                    req.setAttribute("expenses", expenses);
                    req.getRequestDispatcher("/WEB-INF/views/expense/viewExpenses.jsp").forward(req, res);
                    break;
                case "/edit":
                    int editId = Integer.parseInt(req.getParameter("id"));
                    Expense toEdit = expenseDAO.findById(editId, userId);
                    if (toEdit == null) { res.sendRedirect(req.getContextPath() + "/expense/list"); return; }
                    req.setAttribute("expense", toEdit);
                    req.getRequestDispatcher("/WEB-INF/views/expense/editExpense.jsp").forward(req, res);
                    break;
                case "/view":
                    int viewId = Integer.parseInt(req.getParameter("id"));
                    Expense toView = expenseDAO.findById(viewId, userId);
                    if (toView == null) { res.sendRedirect(req.getContextPath() + "/expense/list"); return; }
                    req.setAttribute("expense", toView);
                    req.getRequestDispatcher("/WEB-INF/views/expense/expenseDetails.jsp").forward(req, res);
                    break;
                case "/delete":
                    int delId = Integer.parseInt(req.getParameter("id"));
                    expenseDAO.delete(delId, userId);
                    res.sendRedirect(req.getContextPath() + "/expense/list");
                    break;
                default:
                    res.sendRedirect(req.getContextPath() + "/expense/list");
            }
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String path = req.getPathInfo();
        if (path == null) path = "/add";
        int userId = SessionUtil.getUserId(req);

        try {
            if (path.equals("/add")) {
                handleSave(req, res, userId, null);
            } else if (path.equals("/edit")) {
                int id = Integer.parseInt(req.getParameter("id"));
                handleSave(req, res, userId, id);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void handleSave(HttpServletRequest req, HttpServletResponse res, int userId, Integer expenseId)
            throws SQLException, ServletException, IOException {
        String title = req.getParameter("title");
        String amountStr = req.getParameter("amount");
        String dateStr = req.getParameter("expenseDate");
        String categoryStr = req.getParameter("categoryId");
        String description = req.getParameter("description");

        if (ValidationUtil.isNullOrEmpty(title) || !ValidationUtil.isPositiveAmount(amountStr)
                || !ValidationUtil.isValidDate(dateStr) || ValidationUtil.isNullOrEmpty(categoryStr)) {
            req.setAttribute("error", "Please fill in all required fields with valid values.");
            String view = expenseId == null ? "/WEB-INF/views/expense/addExpense.jsp" : "/WEB-INF/views/expense/editExpense.jsp";
            req.getRequestDispatcher(view).forward(req, res);
            return;
        }

        Expense expense = new Expense();
        expense.setUserId(userId);
        expense.setTitle(title.trim());
        expense.setAmount(new BigDecimal(amountStr));
        expense.setExpenseDate(Date.valueOf(dateStr));
        expense.setCategoryId(Integer.parseInt(categoryStr));
        expense.setDescription(description != null ? description.trim() : "");

        // Handle receipt upload
        Part filePart = req.getPart("receipt");
        if (filePart != null && filePart.getSize() > 0) {
            String fileName = System.currentTimeMillis() + "_" + filePart.getSubmittedFileName();
            String uploadPath = getServletContext().getRealPath("/") + "uploads/receipts/";
            new java.io.File(uploadPath).mkdirs();
            filePart.write(uploadPath + fileName);
            expense.setReceiptPath("uploads/receipts/" + fileName);
        }

        if (expenseId != null) {
            expense.setId(expenseId);
            expenseDAO.update(expense);
        } else {
            expenseDAO.create(expense);
        }

        res.sendRedirect(req.getContextPath() + "/expense/list");
    }
}

