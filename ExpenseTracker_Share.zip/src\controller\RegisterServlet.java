package controller;

import dao.UserDAO;
import model.User;
import util.SessionUtil;
import util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (SessionUtil.isLoggedIn(req)) {
            res.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }
        req.getRequestDispatcher("/register.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String fullName  = req.getParameter("fullName");
        String username  = req.getParameter("username");
        String email     = req.getParameter("email");
        String password  = req.getParameter("password");
        String confirm   = req.getParameter("confirmPassword");

        String error = validateRegistration(fullName, username, email, password, confirm);
        if (error != null) {
            req.setAttribute("error", error);
            req.setAttribute("fullName", ValidationUtil.sanitize(fullName));
            req.setAttribute("username", ValidationUtil.sanitize(username));
            req.setAttribute("email", ValidationUtil.sanitize(email));
            req.getRequestDispatcher("/register.jsp").forward(req, res);
            return;
        }

        try {
            if (userDAO.usernameExists(username)) {
                req.setAttribute("error", "Username already taken.");
                req.getRequestDispatcher("/register.jsp").forward(req, res);
                return;
            }
            if (userDAO.emailExists(email)) {
                req.setAttribute("error", "Email already registered.");
                req.getRequestDispatcher("/register.jsp").forward(req, res);
                return;
            }

            String hash = BCrypt.hashpw(password, BCrypt.gensalt(10));
            User user = new User(username.trim(), email.trim(), hash, fullName.trim());
            if (userDAO.create(user)) {
                SessionUtil.setUser(req, user);
                res.sendRedirect(req.getContextPath() + "/dashboard");
            } else {
                req.setAttribute("error", "Registration failed. Please try again.");
                req.getRequestDispatcher("/register.jsp").forward(req, res);
            }
        } catch (SQLException e) {
            req.setAttribute("error", "A server error occurred. Please try again.");
            req.getRequestDispatcher("/register.jsp").forward(req, res);
        }
    }

    private String validateRegistration(String fullName, String username, String email, String password, String confirm) {
        if (ValidationUtil.isNullOrEmpty(fullName)) return "Full name is required.";
        if (!ValidationUtil.isValidUsername(username)) return "Username must be 3-50 alphanumeric characters (underscores allowed).";
        if (!ValidationUtil.isValidEmail(email)) return "Please enter a valid email address.";
        if (!ValidationUtil.isValidPassword(password)) return "Password must be at least 6 characters.";
        if (!password.equals(confirm)) return "Passwords do not match.";
        return null;
    }
}

