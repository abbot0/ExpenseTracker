package dao;

import model.Budget;
import util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BudgetDAO {

    public boolean createOrUpdate(Budget budget) throws SQLException {
        String sql = "INSERT INTO budgets (user_id, category_id, month, year, amount) VALUES (?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE amount = VALUES(amount)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, budget.getUserId());
            if (budget.getCategoryId() != null) ps.setInt(2, budget.getCategoryId()); else ps.setNull(2, Types.INTEGER);
            ps.setInt(3, budget.getMonth());
            ps.setInt(4, budget.getYear());
            ps.setBigDecimal(5, budget.getAmount());
            int rows = ps.executeUpdate();
            if (rows > 0 && budget.getId() == 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) budget.setId(keys.getInt(1));
                }
            }
            return rows > 0;
        }
    }

    public boolean delete(int budgetId, int userId) throws SQLException {
        String sql = "DELETE FROM budgets WHERE id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, budgetId);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    public List<Budget> findByUserAndPeriod(int userId, int month, int year) throws SQLException {
        String sql = "SELECT b.*, c.name AS category_name, c.icon AS category_icon, " +
                     "COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.user_id = b.user_id AND e.category_id = b.category_id " +
                     "  AND MONTH(e.expense_date) = b.month AND YEAR(e.expense_date) = b.year), 0) AS spent " +
                     "FROM budgets b LEFT JOIN categories c ON b.category_id = c.id " +
                     "WHERE b.user_id = ? AND b.month = ? AND b.year = ? ORDER BY c.name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            return mapResultSet(ps.executeQuery());
        }
    }

    public Budget findById(int budgetId, int userId) throws SQLException {
        String sql = "SELECT b.*, c.name AS category_name, c.icon AS category_icon, 0 AS spent " +
                     "FROM budgets b LEFT JOIN categories c ON b.category_id = c.id " +
                     "WHERE b.id = ? AND b.user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, budgetId);
            ps.setInt(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public BigDecimal getTotalBudget(int userId, int month, int year) throws SQLException {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM budgets WHERE user_id = ? AND month = ? AND year = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO;
            }
        }
    }

    private List<Budget> mapResultSet(ResultSet rs) throws SQLException {
        List<Budget> list = new ArrayList<>();
        while (rs.next()) list.add(mapRow(rs));
        return list;
    }

    private Budget mapRow(ResultSet rs) throws SQLException {
        Budget b = new Budget();
        b.setId(rs.getInt("id"));
        b.setUserId(rs.getInt("user_id"));
        int catId = rs.getInt("category_id");
        b.setCategoryId(rs.wasNull() ? null : catId);
        b.setCategoryName(rs.getString("category_name"));
        b.setCategoryIcon(rs.getString("category_icon"));
        b.setMonth(rs.getInt("month"));
        b.setYear(rs.getInt("year"));
        b.setAmount(rs.getBigDecimal("amount"));
        b.setSpent(rs.getBigDecimal("spent"));
        b.setCreatedAt(rs.getTimestamp("created_at"));
        b.setUpdatedAt(rs.getTimestamp("updated_at"));
        return b;
    }
}
