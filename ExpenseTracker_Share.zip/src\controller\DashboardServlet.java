package controller;

import dao.BudgetDAO;
import dao.ExpenseDAO;
import model.Budget;
import model.Expense;
import util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private final ExpenseDAO expenseDAO = new ExpenseDAO();
    private final BudgetDAO budgetDAO = new BudgetDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int userId = SessionUtil.getUserId(req);
        LocalDate now = LocalDate.now();
        int month = now.getMonthValue();
        int year = now.getYear();

        try {
            List<Expense> recentExpenses = expenseDAO.findRecent(userId, 5);
            BigDecimal monthTotal = expenseDAO.getTotalByUserAndMonth(userId, month, year);
            BigDecimal totalBudget = budgetDAO.getTotalBudget(userId, month, year);
            List<Budget> budgets = budgetDAO.findByUserAndPeriod(userId, month, year);
            Map<String, BigDecimal> categoryTotals = expenseDAO.getCategoryTotals(userId, month, year);
            Map<String, BigDecimal> monthlyTotals = expenseDAO.getMonthlyTotals(userId, year);

            req.setAttribute("recentExpenses", recentExpenses);
            req.setAttribute("monthTotal", monthTotal);
            req.setAttribute("totalBudget", totalBudget);
            req.setAttribute("budgets", budgets);
            req.setAttribute("categoryTotals", categoryTotals);
            req.setAttribute("monthlyTotals", monthlyTotals);
            req.setAttribute("currentMonth", now.getMonth().getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ENGLISH));
            req.setAttribute("currentYear", year);

            req.getRequestDispatcher("/WEB-INF/views/dashboard/dashboard.jsp").forward(req, res);
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}

