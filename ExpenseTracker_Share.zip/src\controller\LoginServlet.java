package controller;

import dao.UserDAO;
import model.User;
import util.SessionUtil;
import util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (SessionUtil.isLoggedIn(req)) {
            res.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }
        req.getRequestDispatcher("/login.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if (ValidationUtil.isNullOrEmpty(username) || ValidationUtil.isNullOrEmpty(password)) {
            req.setAttribute("error", "Please fill in all fields.");
            req.getRequestDispatcher("/login.jsp").forward(req, res);
            return;
        }

        try {
            User user = userDAO.findByUsername(username.trim());
            if (user != null && BCrypt.checkpw(password, user.getPasswordHash())) {
                SessionUtil.setUser(req, user);
                res.sendRedirect(req.getContextPath() + "/dashboard");
            } else {
                req.setAttribute("error", "Invalid username or password.");
                req.setAttribute("username", ValidationUtil.sanitize(username));
                req.getRequestDispatcher("/login.jsp").forward(req, res);
            }
        } catch (SQLException e) {
            req.setAttribute("error", "A server error occurred. Please try again.");
            req.getRequestDispatcher("/login.jsp").forward(req, res);
        }
    }
}

