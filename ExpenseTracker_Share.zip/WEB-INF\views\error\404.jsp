<%@ page contentType="text/html;charset=UTF-8" isErrorPage="true" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>404 - Not Found</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100 bg-light">
<div class="text-center">
    <i class="bi bi-exclamation-triangle text-warning" style="font-size:4rem"></i>
    <h1 class="display-4 fw-bold mt-3">404</h1>
    <p class="text-muted">The page you're looking for doesn't exist.</p>
    <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-primary">
        <i class="bi bi-house me-2"></i>Back to Dashboard
    </a>
</div>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

