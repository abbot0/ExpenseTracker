﻿<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access Denied</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100 bg-light">
<div class="text-center">
    <i class="bi bi-shield-lock text-danger" style="font-size:4rem"></i>
    <h1 class="display-4 fw-bold mt-3">403</h1>
    <p class="text-muted">You don't have permission to access this page.</p>
    <a href="${pageContext.request.contextPath}/login" class="btn btn-primary">
        <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
    </a>
</div>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

