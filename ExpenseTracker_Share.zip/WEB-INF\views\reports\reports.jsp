<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.Map, java.math.BigDecimal" %>
<%
    Map<String, BigDecimal> monthlyTotals  = (Map<String, BigDecimal>) request.getAttribute("monthlyTotals");
    Map<String, BigDecimal> categoryTotals = (Map<String, BigDecimal>) request.getAttribute("categoryTotals");
    int year = (int) request.getAttribute("year");
    BigDecimal yearTotal = monthlyTotals.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add);
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h5 class="mb-0"><i class="bi bi-bar-chart-line me-2 text-primary"></i>Reports  -  <%= year %></h5>
        <div class="d-flex gap-2 align-items-center">
            <form class="d-flex gap-2" method="get" action="${pageContext.request.contextPath}/reports/">
                <select class="form-select form-select-sm" name="year" onchange="this.form.submit()">
                    <% for (int y = year; y >= year - 4; y--) { %>
                    <option value="<%= y %>" <%= y == year ? "selected" : "" %>><%= y %></option>
                    <% } %>
                </select>
            </form>
        </div>
    </div>

    <!-- Year total banner -->
    <div class="alert alert-primary d-flex align-items-center gap-3 mb-4">
        <i class="bi bi-calendar-check fs-4"></i>
        <div>
            <strong>Total spent in <%= year %>:</strong>
            <span class="fs-5 ms-2">&#8377;<%= String.format("%.2f", yearTotal) %></span>
        </div>
    </div>

    <div class="row g-4">
        <!-- Monthly bar chart -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0">
                    <h6 class="mb-0"><i class="bi bi-bar-chart me-2 text-primary"></i>Monthly Breakdown</h6>
                </div>
                <div class="card-body">
                    <canvas id="monthlyChart" height="160"></canvas>
                </div>
            </div>
        </div>
        <!-- Category pie chart -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0">
                    <h6 class="mb-0"><i class="bi bi-pie-chart me-2 text-primary"></i>Category Split (Current Month)</h6>
                </div>
                <div class="card-body d-flex align-items-center justify-content-center">
                    <% if (categoryTotals.isEmpty()) { %>
                    <p class="text-muted">No data for current month.</p>
                    <% } else { %>
                    <canvas id="categoryChart"></canvas>
                    <% } %>
                </div>
            </div>
        </div>
    </div>

    <!-- Monthly table -->
    <div class="card border-0 shadow-sm mt-4">
        <div class="card-header bg-transparent border-0"><h6 class="mb-0">Monthly Summary</h6></div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr><th>Month</th><th>Total Spent</th><th>% of Year</th><th>Bar</th></tr>
                    </thead>
                    <tbody>
                        <% for (Map.Entry<String, BigDecimal> entry : monthlyTotals.entrySet()) {
                            double pct = yearTotal.compareTo(BigDecimal.ZERO) > 0
                                ? entry.getValue().multiply(new BigDecimal("100")).divide(yearTotal, 1, java.math.RoundingMode.HALF_UP).doubleValue()
                                : 0; %>
                        <tr>
                            <td><%= entry.getKey() %></td>
                            <td><strong>&#8377;<%= String.format("%.2f", entry.getValue()) %></strong></td>
                            <td><%= String.format("%.1f", pct) %>%</td>
                            <td style="width:200px">
                                <div class="progress" style="height:8px">
                                    <div class="progress-bar bg-primary" style="width:<%= pct %>%"></div>
                                </div>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="${pageContext.request.contextPath}/assets/vendor/chart.min.js"></script>
<script>
new Chart(document.getElementById('monthlyChart'), {
    type: 'bar',
    data: {
        labels: [<% for (String k : monthlyTotals.keySet()) { %>'<%= k %>',<% } %>],
        datasets: [{
            label: 'Spending (&#8377;)',
            data: [<% for (BigDecimal v : monthlyTotals.values()) { %><%= v %>,<% } %>],
            backgroundColor: 'rgba(99,102,241,0.7)',
            borderRadius: 6
        }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
});
<% if (!categoryTotals.isEmpty()) { %>
new Chart(document.getElementById('categoryChart'), {
    type: 'pie',
    data: {
        labels: [<% for (String k : categoryTotals.keySet()) { %>'<%= k %>',<% } %>],
        datasets: [{
            data: [<% for (BigDecimal v : categoryTotals.values()) { %><%= v %>,<% } %>],
            backgroundColor: ['#6366f1','#f59e0b','#10b981','#ef4444','#3b82f6','#8b5cf6','#ec4899','#14b8a6','#f97316','#64748b']
        }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});
<% } %>
</script>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

