﻿-- MariaDB dump 10.19  Distrib 10.11.7-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: expense_tracker
-- ------------------------------------------------------
-- Server version	10.11.7-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `month` int(11) NOT NULL CHECK (`month` between 1 and 12),
  `year` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_budget` (`user_id`,`category_id`,`month`,`year`),
  KEY `category_id` (`category_id`),
  KEY `idx_budgets_user_period` (`user_id`,`year`,`month`),
  CONSTRAINT `budgets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budgets_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
INSERT INTO `budgets` VALUES
(1,1,1,6,2026,400.00,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(2,1,2,6,2026,150.00,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(3,1,3,6,2026,1200.00,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(4,1,4,6,2026,100.00,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(5,1,5,6,2026,100.00,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(6,1,6,6,2026,200.00,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(7,1,8,6,2026,200.00,'2026-06-09 10:23:02','2026-06-09 10:23:02');
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `icon` varchar(50) DEFAULT 'bi-tag',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Food & Dining','bi-cup-straw'),
(2,'Transportation','bi-car-front'),
(3,'Housing','bi-house'),
(4,'Entertainment','bi-controller'),
(5,'Healthcare','bi-heart-pulse'),
(6,'Shopping','bi-bag'),
(7,'Education','bi-book'),
(8,'Utilities','bi-lightning'),
(9,'Travel','bi-airplane'),
(10,'Other','bi-three-dots');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `expense_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `receipt_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_expenses_user_date` (`user_id`,`expense_date`),
  KEY `idx_expenses_category` (`category_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES
(1,1,1,'Grocery Store',85.50,'2026-06-07','Weekly groceries',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(2,1,2,'Gas Station',45.00,'2026-06-06','Fuel for car',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(3,1,4,'Netflix',15.99,'2026-06-04','Monthly subscription',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(4,1,1,'Restaurant Dinner',62.00,'2026-06-02','Dinner with family',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(5,1,8,'Electric Bill',120.00,'2026-05-30','Monthly electricity',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(6,1,6,'Amazon Order',89.99,'2026-05-28','Home supplies',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(7,1,5,'Pharmacy',34.50,'2026-05-25','Medications',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(8,1,2,'Uber',18.75,'2026-05-22','Ride to airport',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(9,1,1,'Coffee Shop',12.40,'2026-05-20','Morning coffee',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(10,1,7,'Online Course',49.00,'2026-05-15','Java programming course',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(11,1,1,'Grocery Store',92.30,'2026-05-10','Monthly groceries',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(12,1,3,'Rent',1200.00,'2026-05-08','Monthly rent',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(13,1,9,'Hotel',250.00,'2026-04-25','Weekend trip',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(14,1,4,'Cinema',28.00,'2026-04-20','Movie night',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02'),
(15,1,8,'Internet Bill',60.00,'2026-04-10','Monthly internet',NULL,'2026-06-09 10:23:02','2026-06-09 10:23:02');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'johndoe','john@example.com','$2a$10$2uspxbG7tP9a41i96vlvLunDIorV/m/VbD1hbudy5vs9NWGD9rx8y','John Doe','2026-06-09 10:23:02','2026-06-09 10:31:53'),
(2,'janedoe','jane@example.com','$2a$10$2uspxbG7tP9a41i96vlvLunDIorV/m/VbD1hbudy5vs9NWGD9rx8y','Jane Doe','2026-06-09 10:23:02','2026-06-09 10:31:53'),
(3,'jonedoe','example@123gmail.com','$2a$10$aZMQ/Kt.c6bkxuBF0dQB9u0qwXPLE4IccX/tZMZyP83bpr3/rObkK','johedoe','2026-06-09 10:28:04','2026-06-09 10:28:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-09 16:29:03
