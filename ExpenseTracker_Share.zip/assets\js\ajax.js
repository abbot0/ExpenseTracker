'use strict';

// Generic AJAX helpers for report and category data endpoints.

const Ajax = {
    get: function (url, params, onSuccess, onError) {
        const query = params ? '?' + new URLSearchParams(params).toString() : '';
        fetch(url + query, { credentials: 'same-origin' })
            .then(function (res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.json();
            })
            .then(onSuccess)
            .catch(onError || console.error);
    },

    loadCategoryReport: function (contextPath, month, year, callback) {
        Ajax.get(contextPath + '/reports/category-data', { month, year }, callback);
    },

    loadMonthlyReport: function (contextPath, year, callback) {
        Ajax.get(contextPath + '/reports/monthly-data', { year }, callback);
    }
};
