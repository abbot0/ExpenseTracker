package controller;

import dao.ExpenseDAO;
import util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Map;

import com.google.gson.Gson;

@WebServlet("/reports/*")
public class ReportServlet extends HttpServlet {

    private final ExpenseDAO expenseDAO = new ExpenseDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String path = req.getPathInfo();
        if (path == null) path = "/";
        int userId = SessionUtil.getUserId(req);
        LocalDate now = LocalDate.now();

        if (path.equals("/category-data") || path.equals("/monthly-data")) {
            handleAjax(req, res, userId, path, now);
            return;
        }

        int year = now.getYear();
        try {
            String yearParam = req.getParameter("year");
            if (yearParam != null) year = Integer.parseInt(yearParam);
        } catch (NumberFormatException ignored) {}

        try {
            Map<String, BigDecimal> monthlyTotals = expenseDAO.getMonthlyTotals(userId, year);
            Map<String, BigDecimal> categoryTotals = expenseDAO.getCategoryTotals(userId, now.getMonthValue(), year);
            req.setAttribute("monthlyTotals", monthlyTotals);
            req.setAttribute("categoryTotals", categoryTotals);
            req.setAttribute("year", year);
            req.getRequestDispatcher("/WEB-INF/views/reports/reports.jsp").forward(req, res);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void handleAjax(HttpServletRequest req, HttpServletResponse res, int userId, String path, LocalDate now)
            throws IOException {
        res.setContentType("application/json");
        res.setCharacterEncoding("UTF-8");
        int month = now.getMonthValue();
        int year = now.getYear();
        try {
            String m = req.getParameter("month");
            String y = req.getParameter("year");
            if (m != null) month = Integer.parseInt(m);
            if (y != null) year = Integer.parseInt(y);
        } catch (NumberFormatException ignored) {}

        try (PrintWriter out = res.getWriter()) {
            Map<String, BigDecimal> data;
            if (path.equals("/category-data")) {
                data = expenseDAO.getCategoryTotals(userId, month, year);
            } else {
                data = expenseDAO.getMonthlyTotals(userId, year);
            }
            out.print(gson.toJson(data));
        } catch (SQLException e) {
            res.setStatus(500);
        }
    }
}

