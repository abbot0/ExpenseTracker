<%@ page import="model.User, util.SessionUtil" %>
<%
    User navUser = SessionUtil.getUser(request);
    String ctxPath = request.getContextPath();
    String uri = request.getRequestURI();
%>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow-sm">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<%= ctxPath %>/dashboard">
            <i class="bi bi-wallet2 me-2"></i>ExpenseTracker
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <%= uri.contains("/dashboard") ? "active" : "" %>" href="<%= ctxPath %>/dashboard">
                        <i class="bi bi-speedometer2 me-1"></i>Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <%= uri.contains("/expense") ? "active" : "" %>" href="<%= ctxPath %>/expense/list">
                        <i class="bi bi-receipt me-1"></i>Expenses
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <%= uri.contains("/budget") ? "active" : "" %>" href="<%= ctxPath %>/budget/">
                        <i class="bi bi-pie-chart me-1"></i>Budget
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <%= uri.contains("/reports") ? "active" : "" %>" href="<%= ctxPath %>/reports/">
                        <i class="bi bi-bar-chart-line me-1"></i>Reports
                    </a>
                </li>
            </ul>
            <div class="d-flex align-items-center gap-2">
                <% if (navUser != null) { %>
                <span class="text-white-50 small"><i class="bi bi-person-circle me-1"></i><%= navUser.getFullName() %></span>
                <a href="<%= ctxPath %>/logout" class="btn btn-sm btn-outline-light">
                    <i class="bi bi-box-arrow-right me-1"></i>Logout
                </a>
                <% } %>
            </div>
        </div>
    </div>
</nav>
