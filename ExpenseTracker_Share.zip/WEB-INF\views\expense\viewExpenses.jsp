<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.Expense, java.util.List" %>
<%
    List<Expense> expenses = (List<Expense>) request.getAttribute("expenses");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expenses - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="mb-0"><i class="bi bi-receipt me-2 text-primary"></i>All Expenses</h5>
        <div class="d-flex gap-2">
            <input type="text" id="searchInput" class="form-control form-control-sm" placeholder="Search..." style="width:200px">
            <a href="${pageContext.request.contextPath}/expense/add" class="btn btn-sm btn-primary">
                <i class="bi bi-plus me-1"></i>Add
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <% if (expenses.isEmpty()) { %>
            <div class="text-center py-5">
                <i class="bi bi-inbox text-muted fs-1"></i>
                <p class="text-muted mt-2">No expenses yet.</p>
                <a href="${pageContext.request.contextPath}/expense/add" class="btn btn-primary">Add your first expense</a>
            </div>
            <% } else { %>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="expensesTable">
                    <thead class="table-light">
                        <tr>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Description</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (Expense e : expenses) { %>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="expense-icon-sm"><i class="bi <%= e.getCategoryIcon() %>"></i></div>
                                    <span class="fw-medium"><%= e.getTitle() %></span>
                                </div>
                            </td>
                            <td><span class="badge bg-secondary-subtle text-secondary"><%= e.getCategoryName() %></span></td>
                            <td><strong class="text-danger">&#8377;<%= String.format("%.2f", e.getAmount()) %></strong></td>
                            <td class="text-muted small"><%= e.getExpenseDate() %></td>
                            <td class="text-muted small text-truncate" style="max-width:150px">
                                <%= e.getDescription() != null ? e.getDescription() : "" %>
                            </td>
                            <td class="text-end">
                                <a href="${pageContext.request.contextPath}/expense/view?id=<%= e.getId() %>"
                                   class="btn btn-xs btn-outline-secondary me-1" title="View">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="${pageContext.request.contextPath}/expense/edit?id=<%= e.getId() %>"
                                   class="btn btn-xs btn-outline-primary me-1" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="${pageContext.request.contextPath}/expense/delete?id=<%= e.getId() %>"
                                   class="btn btn-xs btn-outline-danger" title="Delete"
                                   onclick="return confirm('Delete this expense?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
            <% } %>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/assets/vendor/jquery.min.js"></script>
<script>
$('#searchInput').on('input', function () {
    const q = $(this).val().toLowerCase();
    $('#expensesTable tbody tr').each(function () {
        $(this).toggle($(this).text().toLowerCase().includes(q));
    });
});
</script>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

