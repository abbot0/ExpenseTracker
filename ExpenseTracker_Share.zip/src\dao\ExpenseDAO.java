package dao;

import model.Expense;
import util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ExpenseDAO {

    public boolean create(Expense expense) throws SQLException {
        String sql = "INSERT INTO expenses (user_id, category_id, title, amount, expense_date, description, receipt_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, expense.getUserId());
            ps.setInt(2, expense.getCategoryId());
            ps.setString(3, expense.getTitle());
            ps.setBigDecimal(4, expense.getAmount());
            ps.setDate(5, expense.getExpenseDate());
            ps.setString(6, expense.getDescription());
            ps.setString(7, expense.getReceiptPath());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) expense.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Expense expense) throws SQLException {
        String sql = "UPDATE expenses SET category_id=?, title=?, amount=?, expense_date=?, description=?, receipt_path=? WHERE id=? AND user_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, expense.getCategoryId());
            ps.setString(2, expense.getTitle());
            ps.setBigDecimal(3, expense.getAmount());
            ps.setDate(4, expense.getExpenseDate());
            ps.setString(5, expense.getDescription());
            ps.setString(6, expense.getReceiptPath());
            ps.setInt(7, expense.getId());
            ps.setInt(8, expense.getUserId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int expenseId, int userId) throws SQLException {
        String sql = "DELETE FROM expenses WHERE id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, expenseId);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    public Expense findById(int expenseId, int userId) throws SQLException {
        String sql = "SELECT e.*, c.name AS category_name, c.icon AS category_icon " +
                     "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                     "WHERE e.id = ? AND e.user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, expenseId);
            ps.setInt(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Expense> findByUser(int userId) throws SQLException {
        String sql = "SELECT e.*, c.name AS category_name, c.icon AS category_icon " +
                     "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                     "WHERE e.user_id = ? ORDER BY e.expense_date DESC, e.created_at DESC";
        return executeListQuery(sql, userId);
    }

    public List<Expense> findByUserAndMonth(int userId, int month, int year) throws SQLException {
        String sql = "SELECT e.*, c.name AS category_name, c.icon AS category_icon " +
                     "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                     "WHERE e.user_id = ? AND MONTH(e.expense_date) = ? AND YEAR(e.expense_date) = ? " +
                     "ORDER BY e.expense_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            return mapResultSet(ps.executeQuery());
        }
    }

    public List<Expense> findByUserAndCategory(int userId, int categoryId) throws SQLException {
        String sql = "SELECT e.*, c.name AS category_name, c.icon AS category_icon " +
                     "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                     "WHERE e.user_id = ? AND e.category_id = ? ORDER BY e.expense_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, categoryId);
            return mapResultSet(ps.executeQuery());
        }
    }

    public List<Expense> findRecent(int userId, int limit) throws SQLException {
        String sql = "SELECT e.*, c.name AS category_name, c.icon AS category_icon " +
                     "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                     "WHERE e.user_id = ? ORDER BY e.expense_date DESC, e.created_at DESC LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, limit);
            return mapResultSet(ps.executeQuery());
        }
    }

    public BigDecimal getTotalByUserAndMonth(int userId, int month, int year) throws SQLException {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE user_id = ? AND MONTH(expense_date) = ? AND YEAR(expense_date) = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO;
            }
        }
    }

    public Map<String, BigDecimal> getCategoryTotals(int userId, int month, int year) throws SQLException {
        String sql = "SELECT c.name, COALESCE(SUM(e.amount), 0) AS total " +
                     "FROM expenses e JOIN categories c ON e.category_id = c.id " +
                     "WHERE e.user_id = ? AND MONTH(e.expense_date) = ? AND YEAR(e.expense_date) = ? " +
                     "GROUP BY c.id, c.name ORDER BY total DESC";
        Map<String, BigDecimal> map = new LinkedHashMap<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) map.put(rs.getString("name"), rs.getBigDecimal("total"));
            }
        }
        return map;
    }

    public Map<String, BigDecimal> getMonthlyTotals(int userId, int year) throws SQLException {
        String sql = "SELECT MONTH(expense_date) AS m, COALESCE(SUM(amount), 0) AS total " +
                     "FROM expenses WHERE user_id = ? AND YEAR(expense_date) = ? " +
                     "GROUP BY MONTH(expense_date) ORDER BY m";
        Map<String, BigDecimal> map = new LinkedHashMap<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, year);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String[] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
                    int m = rs.getInt("m");
                    map.put(months[m - 1], rs.getBigDecimal("total"));
                }
            }
        }
        return map;
    }

    private List<Expense> executeListQuery(String sql, int userId) throws SQLException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return mapResultSet(ps.executeQuery());
        }
    }

    private List<Expense> mapResultSet(ResultSet rs) throws SQLException {
        List<Expense> list = new ArrayList<>();
        while (rs.next()) list.add(mapRow(rs));
        return list;
    }

    private Expense mapRow(ResultSet rs) throws SQLException {
        Expense e = new Expense();
        e.setId(rs.getInt("id"));
        e.setUserId(rs.getInt("user_id"));
        e.setCategoryId(rs.getInt("category_id"));
        e.setCategoryName(rs.getString("category_name"));
        e.setCategoryIcon(rs.getString("category_icon"));
        e.setTitle(rs.getString("title"));
        e.setAmount(rs.getBigDecimal("amount"));
        e.setExpenseDate(rs.getDate("expense_date"));
        e.setDescription(rs.getString("description"));
        e.setReceiptPath(rs.getString("receipt_path"));
        e.setCreatedAt(rs.getTimestamp("created_at"));
        e.setUpdatedAt(rs.getTimestamp("updated_at"));
        return e;
    }
}
