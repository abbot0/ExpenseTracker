<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.Expense" %>
<% Expense expense = (Expense) request.getAttribute("expense"); %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Details - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>
<div class="container py-4" style="max-width:600px">
    <div class="d-flex align-items-center gap-2 mb-4">
        <a href="${pageContext.request.contextPath}/expense/list" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left"></i>
        </a>
        <h5 class="mb-0">Expense Details</h5>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <div class="text-center mb-4">
                <div class="expense-icon-lg mx-auto mb-2">
                    <i class="bi <%= expense.getCategoryIcon() %> fs-2"></i>
                </div>
                <h3 class="text-danger mb-0">&#8377;<%= String.format("%.2f", expense.getAmount()) %></h3>
                <h5 class="mt-1"><%= expense.getTitle() %></h5>
                <span class="badge bg-primary"><%= expense.getCategoryName() %></span>
            </div>
            <hr>
            <dl class="row">
                <dt class="col-sm-4">Date</dt>
                <dd class="col-sm-8"><%= expense.getExpenseDate() %></dd>
                <dt class="col-sm-4">Category</dt>
                <dd class="col-sm-8"><%= expense.getCategoryName() %></dd>
                <dt class="col-sm-4">Description</dt>
                <dd class="col-sm-8"><%= expense.getDescription() != null && !expense.getDescription().isEmpty() ? expense.getDescription() : "<span class='text-muted'>â€”</span>" %></dd>
                <dt class="col-sm-4">Added</dt>
                <dd class="col-sm-8 text-muted small"><%= expense.getCreatedAt() %></dd>
                <% if (expense.getReceiptPath() != null && !expense.getReceiptPath().isEmpty()) { %>
                <dt class="col-sm-4">Receipt</dt>
                <dd class="col-sm-8">
                    <a href="${pageContext.request.contextPath}/<%= expense.getReceiptPath() %>" target="_blank" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-paperclip me-1"></i>View Receipt
                    </a>
                </dd>
                <% } %>
            </dl>
            <div class="d-flex gap-2 mt-3">
                <a href="${pageContext.request.contextPath}/expense/edit?id=<%= expense.getId() %>" class="btn btn-primary flex-fill">
                    <i class="bi bi-pencil me-2"></i>Edit
                </a>
                <a href="${pageContext.request.contextPath}/expense/delete?id=<%= expense.getId() %>"
                   class="btn btn-outline-danger"
                   onclick="return confirm('Delete this expense?')">
                    <i class="bi bi-trash"></i>
                </a>
            </div>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

