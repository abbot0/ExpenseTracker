package model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Budget {
    private int id;
    private int userId;
    private Integer categoryId;
    private String categoryName;
    private String categoryIcon;
    private int month;
    private int year;
    private BigDecimal amount;
    private BigDecimal spent;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public Budget() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public Integer getCategoryId() { return categoryId; }
    public void setCategoryId(Integer categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getCategoryIcon() { return categoryIcon; }
    public void setCategoryIcon(String categoryIcon) { this.categoryIcon = categoryIcon; }

    public int getMonth() { return month; }
    public void setMonth(int month) { this.month = month; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public BigDecimal getSpent() { return spent != null ? spent : BigDecimal.ZERO; }
    public void setSpent(BigDecimal spent) { this.spent = spent; }

    public BigDecimal getRemaining() {
        return amount.subtract(getSpent());
    }

    public double getPercentUsed() {
        if (amount.compareTo(BigDecimal.ZERO) == 0) return 0;
        return getSpent().multiply(new BigDecimal("100")).divide(amount, 1, java.math.RoundingMode.HALF_UP).doubleValue();
    }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public Timestamp getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Timestamp updatedAt) { this.updatedAt = updatedAt; }
}
