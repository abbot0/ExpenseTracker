<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.Budget, java.util.List, java.math.BigDecimal" %>
<%
    List<Budget> budgets = (List<Budget>) request.getAttribute("budgets");
    int month = (int) request.getAttribute("month");
    int year = (int) request.getAttribute("year");
    String monthName = (String) request.getAttribute("monthName");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h5 class="mb-0"><i class="bi bi-pie-chart me-2 text-primary"></i>Budgets  -  <%= monthName %> <%= year %></h5>
        <div class="d-flex gap-2">
            <% int prevMonth = month == 1 ? 12 : month - 1;
               int prevYear  = month == 1 ? year - 1 : year;
               int nextMonth = month == 12 ? 1 : month + 1;
               int nextYear  = month == 12 ? year + 1 : year; %>
            <a href="${pageContext.request.contextPath}/budget/?month=<%= prevMonth %>&year=<%= prevYear %>" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-chevron-left"></i>
            </a>
            <a href="${pageContext.request.contextPath}/budget/?month=<%= nextMonth %>&year=<%= nextYear %>" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-chevron-right"></i>
            </a>
        </div>
    </div>

    <div class="row g-4">
        <!-- Add Budget Form -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0"><h6 class="mb-0">Set Budget</h6></div>
                <div class="card-body">
                    <form action="${pageContext.request.contextPath}/budget/" method="post">
                        <input type="hidden" name="month" value="<%= month %>">
                        <input type="hidden" name="year" value="<%= year %>">
                        <div class="mb-3">
                            <label class="form-label">Category <span class="text-danger">*</span></label>
                            <select class="form-select" name="categoryId" required>
                                <option value="">Select category...</option>
                                <option value="1">ðŸœ Food &amp; Dining</option>
                                <option value="2">ðŸš -  Transportation</option>
                                <option value="3">ðŸ  Housing</option>
                                <option value="4">ðŸŽ® Entertainment</option>
                                <option value="5">â¤ï¸ Healthcare</option>
                                <option value="6">ðŸ›ï¸ Shopping</option>
                                <option value="7">ðŸ“š Education</option>
                                <option value="8">âš¡ Utilities</option>
                                <option value="9">âœˆï¸ Travel</option>
                                <option value="10">ðŸ“Œ Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Budget Amount (&#8377;) <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">&#8377;</span>
                                <input type="number" class="form-control" name="amount" step="0.01" min="0.01" placeholder="0.00" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-plus-circle me-2"></i>Save Budget
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Budget List -->
        <div class="col-lg-8">
            <% if (budgets.isEmpty()) { %>
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-5">
                    <i class="bi bi-pie-chart text-muted fs-1"></i>
                    <p class="text-muted mt-2">No budgets set for this period.</p>
                </div>
            </div>
            <% } else { %>
            <div class="row g-3">
                <% for (Budget b : budgets) {
                    double pct = b.getPercentUsed();
                    String barClass = pct >= 100 ? "bg-danger" : pct >= 80 ? "bg-warning" : "bg-success";
                    String cardBorder = pct >= 100 ? "border-danger" : ""; %>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100 <%= cardBorder %>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <i class="bi <%= b.getCategoryIcon() != null ? b.getCategoryIcon() : "bi-tag" %> me-1 text-primary"></i>
                                    <strong><%= b.getCategoryName() %></strong>
                                    <% if (pct >= 100) { %><span class="badge bg-danger ms-1">Over budget</span><% } %>
                                </div>
                                <a href="${pageContext.request.contextPath}/budget/delete?id=<%= b.getId() %>"
                                   class="btn btn-xs btn-outline-danger"
                                   onclick="return confirm('Remove this budget?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </div>
                            <div class="d-flex justify-content-between small text-muted mb-1">
                                <span>Spent: &#8377;<%= String.format("%.2f", b.getSpent()) %></span>
                                <span>Budget: &#8377;<%= String.format("%.2f", b.getAmount()) %></span>
                            </div>
                            <div class="progress mb-1" style="height:10px">
                                <div class="progress-bar <%= barClass %>" style="width:<%= Math.min(pct,100) %>%"></div>
                            </div>
                            <div class="d-flex justify-content-between small">
                                <span class="text-muted"><%= String.format("%.1f", pct) %>% used</span>
                                <span class="<%= b.getRemaining().compareTo(BigDecimal.ZERO) < 0 ? "text-danger" : "text-success" %>">
                                    &#8377;<%= String.format("%.2f", b.getRemaining()) %> left
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <% } %>
            </div>
            <% } %>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

