<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String ctx = request.getContextPath();
    if (session.getAttribute("loggedInUser") != null) {
        response.sendRedirect(ctx + "/dashboard");
    } else {
        response.sendRedirect(ctx + "/login");
    }
%>
