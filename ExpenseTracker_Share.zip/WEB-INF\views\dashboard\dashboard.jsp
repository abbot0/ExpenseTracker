<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.User, util.SessionUtil, model.Expense, model.Budget, java.util.List, java.util.Map, java.math.BigDecimal" %>
<%
    User currentUser = SessionUtil.getUser(request);
    List<Expense> recentExpenses = (List<Expense>) request.getAttribute("recentExpenses");
    BigDecimal monthTotal = (BigDecimal) request.getAttribute("monthTotal");
    BigDecimal totalBudget = (BigDecimal) request.getAttribute("totalBudget");
    List<Budget> budgets = (List<Budget>) request.getAttribute("budgets");
    Map<String, BigDecimal> categoryTotals = (Map<String, BigDecimal>) request.getAttribute("categoryTotals");
    Map<String, BigDecimal> monthlyTotals = (Map<String, BigDecimal>) request.getAttribute("monthlyTotals");
    String currentMonth = (String) request.getAttribute("currentMonth");
    int currentYear = (int) request.getAttribute("currentYear");

    BigDecimal remaining = totalBudget.subtract(monthTotal);
    double budgetPct = totalBudget.compareTo(BigDecimal.ZERO) > 0
        ? monthTotal.multiply(new BigDecimal("100")).divide(totalBudget, 1, java.math.RoundingMode.HALF_UP).doubleValue()
        : 0;
    String budgetBarClass = budgetPct >= 100 ? "bg-danger" : budgetPct >= 80 ? "bg-warning" : "bg-success";
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - ExpenseTracker</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/dashboard.css">
</head>
<body>
<%@ include file="/WEB-INF/navbar.jsp" %>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-0">Welcome back, <%= currentUser.getFullName().split(" ")[0] %>!</h4>
            <p class="text-muted mb-0"><%= currentMonth %> <%= currentYear %> Overview</p>
        </div>
        <a href="${pageContext.request.contextPath}/expense/add" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>Add Expense
        </a>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted small mb-1">Month Spending</p>
                            <h4 class="mb-0 text-danger">&#8377;<%= String.format("%.2f", monthTotal) %></h4>
                        </div>
                        <div class="stat-icon bg-danger-subtle text-danger"><i class="bi bi-cash-stack"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted small mb-1">Total Budget</p>
                            <h4 class="mb-0 text-primary">&#8377;<%= String.format("%.2f", totalBudget) %></h4>
                        </div>
                        <div class="stat-icon bg-primary-subtle text-primary"><i class="bi bi-pie-chart"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted small mb-1">Remaining Budget</p>
                            <h4 class="mb-0 <%= remaining.compareTo(BigDecimal.ZERO) < 0 ? "text-danger" : "text-success" %>">
                                &#8377;<%= String.format("%.2f", remaining) %>
                            </h4>
                        </div>
                        <div class="stat-icon bg-success-subtle text-success"><i class="bi bi-piggy-bank"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted small mb-1">Budget Used</p>
                            <h4 class="mb-0"><%= String.format("%.1f", budgetPct) %>%</h4>
                        </div>
                        <div class="stat-icon bg-warning-subtle text-warning"><i class="bi bi-bar-chart-line"></i></div>
                    </div>
                    <div class="progress mt-2" style="height:6px">
                        <div class="progress-bar <%= budgetBarClass %>" style="width:<%= Math.min(budgetPct, 100) %>%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Monthly Chart -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pb-0">
                    <h6 class="mb-0"><i class="bi bi-bar-chart me-2 text-primary"></i>Monthly Spending (<%= currentYear %>)</h6>
                </div>
                <div class="card-body">
                    <canvas id="monthlyChart" height="120"></canvas>
                </div>
            </div>
        </div>
        <!-- Category Chart -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pb-0">
                    <h6 class="mb-0"><i class="bi bi-pie-chart me-2 text-primary"></i>By Category</h6>
                </div>
                <div class="card-body d-flex align-items-center justify-content-center">
                    <% if (categoryTotals.isEmpty()) { %>
                    <p class="text-muted text-center">No expenses this month.</p>
                    <% } else { %>
                    <canvas id="categoryChart"></canvas>
                    <% } %>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-0">
        <!-- Budget Progress -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pb-0 d-flex justify-content-between">
                    <h6 class="mb-0"><i class="bi bi-speedometer2 me-2 text-primary"></i>Budget Progress</h6>
                    <a href="${pageContext.request.contextPath}/budget/" class="btn btn-sm btn-outline-primary">Manage</a>
                </div>
                <div class="card-body">
                    <% if (budgets.isEmpty()) { %>
                    <p class="text-muted text-center py-3">No budgets set for this month.
                        <a href="${pageContext.request.contextPath}/budget/">Set budgets</a></p>
                    <% } else { for (Budget b : budgets) {
                        double pct = b.getPercentUsed();
                        String barClass = pct >= 100 ? "bg-danger" : pct >= 80 ? "bg-warning" : "bg-success"; %>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between small mb-1">
                            <span><i class="bi <%= b.getCategoryIcon() != null ? b.getCategoryIcon() : "bi-tag" %> me-1"></i><%= b.getCategoryName() %></span>
                            <span class="text-muted">&#8377;<%= String.format("%.2f", b.getSpent()) %> / &#8377;<%= String.format("%.2f", b.getAmount()) %></span>
                        </div>
                        <div class="progress" style="height:8px">
                            <div class="progress-bar <%= barClass %>" style="width:<%= Math.min(pct,100) %>%" title="<%= String.format("%.1f",pct) %>%"></div>
                        </div>
                    </div>
                    <% } } %>
                </div>
            </div>
        </div>

        <!-- Recent Expenses -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pb-0 d-flex justify-content-between">
                    <h6 class="mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Recent Expenses</h6>
                    <a href="${pageContext.request.contextPath}/expense/list" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <% if (recentExpenses.isEmpty()) { %>
                    <p class="text-muted text-center py-4">No expenses yet. <a href="${pageContext.request.contextPath}/expense/add">Add one!</a></p>
                    <% } else { %>
                    <ul class="list-group list-group-flush">
                        <% for (Expense e : recentExpenses) { %>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-3">
                            <div class="d-flex align-items-center gap-2">
                                <div class="expense-icon"><i class="bi <%= e.getCategoryIcon() %>"></i></div>
                                <div>
                                    <div class="fw-medium small"><%= e.getTitle() %></div>
                                    <div class="text-muted" style="font-size:.75rem"><%= e.getCategoryName() %> Â· <%= e.getExpenseDate() %></div>
                                </div>
                            </div>
                            <span class="badge bg-danger-subtle text-danger">-&#8377;<%= String.format("%.2f", e.getAmount()) %></span>
                        </li>
                        <% } %>
                    </ul>
                    <% } %>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="${pageContext.request.contextPath}/assets/vendor/jquery.min.js"></script>
<script src="${pageContext.request.contextPath}/assets/vendor/chart.min.js"></script>
<script>
const monthlyData = {
    labels: [<% for (String k : monthlyTotals.keySet()) { %>'<%= k %>',<% } %>],
    datasets: [{
        label: 'Spending ($)',
        data: [<% for (BigDecimal v : monthlyTotals.values()) { %><%= v %>,<% } %>],
        backgroundColor: 'rgba(99,102,241,0.15)',
        borderColor: 'rgba(99,102,241,1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4
    }]
};
const categoryData = {
    labels: [<% for (String k : categoryTotals.keySet()) { %>'<%= k %>',<% } %>],
    datasets: [{
        data: [<% for (BigDecimal v : categoryTotals.values()) { %><%= v %>,<% } %>],
        backgroundColor: ['#6366f1','#f59e0b','#10b981','#ef4444','#3b82f6','#8b5cf6','#ec4899','#14b8a6','#f97316','#64748b']
    }]
};
new Chart(document.getElementById('monthlyChart'), {
    type: 'line', data: monthlyData,
    options: { responsive: true, plugins: { legend: { display: false } } }
});
<% if (!categoryTotals.isEmpty()) { %>
new Chart(document.getElementById('categoryChart'), {
    type: 'doughnut', data: categoryData,
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});
<% } %>
</script>
<script src="${pageContext.request.contextPath}/assets/vendor/bootstrap.bundle.min.js"></script>
</body>
</html>

