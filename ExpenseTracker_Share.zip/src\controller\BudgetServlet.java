package controller;

import dao.BudgetDAO;
import model.Budget;
import util.SessionUtil;
import util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

@WebServlet("/budget/*")
public class BudgetServlet extends HttpServlet {

    private final BudgetDAO budgetDAO = new BudgetDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int userId = SessionUtil.getUserId(req);
        String path = req.getPathInfo();
        if (path == null) path = "/";
        LocalDate now = LocalDate.now();

        int month = now.getMonthValue();
        int year = now.getYear();
        try {
            String monthParam = req.getParameter("month");
            String yearParam = req.getParameter("year");
            if (monthParam != null && yearParam != null) {
                month = Integer.parseInt(monthParam);
                year = Integer.parseInt(yearParam);
            }
        } catch (NumberFormatException ignored) {}

        if (path.equals("/delete")) {
            try {
                int id = Integer.parseInt(req.getParameter("id"));
                budgetDAO.delete(id, userId);
            } catch (Exception ignored) {}
            res.sendRedirect(req.getContextPath() + "/budget/");
            return;
        }

        try {
            List<Budget> budgets = budgetDAO.findByUserAndPeriod(userId, month, year);
            req.setAttribute("budgets", budgets);
            req.setAttribute("month", month);
            req.setAttribute("year", year);
            req.setAttribute("monthName", LocalDate.of(year, month, 1)
                    .getMonth().getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ENGLISH));
            req.getRequestDispatcher("/WEB-INF/views/budget/budget.jsp").forward(req, res);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int userId = SessionUtil.getUserId(req);
        String categoryStr = req.getParameter("categoryId");
        String amountStr = req.getParameter("amount");
        String monthStr = req.getParameter("month");
        String yearStr = req.getParameter("year");

        if (!ValidationUtil.isPositiveAmount(amountStr) || ValidationUtil.isNullOrEmpty(monthStr)
                || ValidationUtil.isNullOrEmpty(yearStr)) {
            res.sendRedirect(req.getContextPath() + "/budget/");
            return;
        }

        try {
            Budget budget = new Budget();
            budget.setUserId(userId);
            budget.setCategoryId(ValidationUtil.isNullOrEmpty(categoryStr) ? null : Integer.parseInt(categoryStr));
            budget.setAmount(new BigDecimal(amountStr));
            budget.setMonth(Integer.parseInt(monthStr));
            budget.setYear(Integer.parseInt(yearStr));
            budgetDAO.createOrUpdate(budget);
            res.sendRedirect(req.getContextPath() + "/budget/?month=" + monthStr + "&year=" + yearStr);
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException(e);
        }
    }
}

