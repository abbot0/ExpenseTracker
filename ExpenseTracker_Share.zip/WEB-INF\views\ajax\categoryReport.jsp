<%@ page contentType="application/json;charset=UTF-8" %>
<%@ page import="dao.ExpenseDAO, util.SessionUtil, java.util.Map, java.math.BigDecimal" %>
<%
    int userId = SessionUtil.getUserId(request);
    if (userId == -1) { response.setStatus(401); return; }
    int month = Integer.parseInt(request.getParameter("month") != null ? request.getParameter("month") : String.valueOf(java.time.LocalDate.now().getMonthValue()));
    int year  = Integer.parseInt(request.getParameter("year")  != null ? request.getParameter("year")  : String.valueOf(java.time.LocalDate.now().getYear()));
    ExpenseDAO dao = new ExpenseDAO();
    Map<String, BigDecimal> data = dao.getCategoryTotals(userId, month, year);
    StringBuilder sb = new StringBuilder("{");
    boolean first = true;
    for (Map.Entry<String, BigDecimal> e : data.entrySet()) {
        if (!first) sb.append(",");
        sb.append("\"").append(e.getKey().replace("\"","\\\"")).append("\":").append(e.getValue());
        first = false;
    }
    sb.append("}");
    out.print(sb.toString());
%>
